var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '',
    VERSION: 'master',
    LANGUAGE: 'zh_CN',
    COLLAPSE_INDEX: false,
    FILE_SUFFIX: '.html',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt'
};